function tbk = read_tdt_tbk(filename, begblock, endblock)

% tbk file has block events information and time marks
% for efficiently locate event if query by time
