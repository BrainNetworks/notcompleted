The following files are copied from MATLAB 2007b

inputdlg.m
listdlg.m
getnicedialoglocation.m
setdefaultbutton.m

These files are (c) The MathWorks. They are made available here to provide the
same behaviour of the input dialogs on platforms running MATLAB R14SP3 onwards.
