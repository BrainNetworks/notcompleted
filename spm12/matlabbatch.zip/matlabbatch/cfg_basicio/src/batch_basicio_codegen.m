%-----------------------------------------------------------------------
% Job configuration created by cfg_util (rev $Rev: 4899 $)
%-----------------------------------------------------------------------
matlabbatch{1}.menu_cfg.gencode_gen.gencode_fname = 'cfg_cfg_basicio.m';
matlabbatch{1}.menu_cfg.gencode_gen.gencode_dir = '<UNDEFINED>';
matlabbatch{1}.menu_cfg.gencode_gen.gencode_var = '<UNDEFINED>';
matlabbatch{1}.menu_cfg.gencode_gen.gencode_opts.gencode_o_def = true;
matlabbatch{1}.menu_cfg.gencode_gen.gencode_opts.gencode_o_mlb = false;
matlabbatch{1}.menu_cfg.gencode_gen.gencode_opts.gencode_o_path = false;
