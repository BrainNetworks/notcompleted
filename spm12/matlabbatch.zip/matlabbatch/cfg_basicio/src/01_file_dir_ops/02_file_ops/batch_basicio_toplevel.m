%-----------------------------------------------------------------------
% Job saved on 25-Sep-2013 15:09:26 by cfg_util (rev $Rev: 5685 $)
% spm SPM - SPM12b (beta)
% cfg_basicio BasicIO - Unknown
% cfg_logextract LogExt - Unknown
% tbx_dpc dPC Tools - Unknown
% perfusion Perfusion - Unknown
% dtijobs DTI tools - Unknown
% impexp_NiftiMrStruct NiftiMrStruct - Unknown
% prt PRoNTo - Unknown
% menu_cfg ConfGUI - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.menu_cfg.menu_struct.conf_choice.type = 'cfg_choice';
matlabbatch{1}.menu_cfg.menu_struct.conf_choice.name = 'File Operations';
matlabbatch{1}.menu_cfg.menu_struct.conf_choice.tag = 'file_ops';
matlabbatch{1}.menu_cfg.menu_struct.conf_choice.values = {
                                                          '<UNDEFINED>'
                                                          '<UNDEFINED>'
                                                          '<UNDEFINED>'
                                                          '<UNDEFINED>'
                                                          '<UNDEFINED>'
                                                          '<UNDEFINED>'
                                                          '<UNDEFINED>'
                                                          }';
matlabbatch{1}.menu_cfg.menu_struct.conf_choice.check = [];
matlabbatch{1}.menu_cfg.menu_struct.conf_choice.help = {''};
